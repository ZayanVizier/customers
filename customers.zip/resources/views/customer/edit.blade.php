@extends('layout')

@section('content')


    <div class="card">
        <div class="card-header">
            <h1 class="float-left">Create Customer</h1> 
            <a href="/customer" class="btn btn-secondary float-right mt-2">Back</a>
        </div>
        <div class="card-body">
                <form action="/customer/{{ $customer->id }}" method="POST" name="request">
                    @method('PATCH')
                    @csrf
                    <div class="form-group">
                        <label for="InputName">Name</label>
                        <input type="text" class="form-control" id="InputName" name="name" value="{{ $customer->name }}" required>
                    </div>
                    <div class="form-group">
                        <label for="InputEmail">Email</label>
                        <input type="email" class="form-control" id="InputEmail" name="email" value="{{ $customer->email }}" required>
                    </div>
                    <div class="form-group">
                        <label for="InputAddress">Address</label>
                        <input type="text" class="form-control" id="InputAddress" name="address" value="{{ $customer->address }}" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
        </div>
        
            @include('errors')
        
    </div>

@endsection