@extends('layout')

@section('content')

    <div class="card">
        <div class="card-header">
            <h2 class="float-left">Customer # {{ $customer->id }}</h2> 
            <a href="/customer" class="btn btn-secondary float-right">Back</a>
        </div>
        <div class="card-body">
              <h4>Customer Name: {{ $customer->name }}</h4>    
              <h4>Customer Email: {{ $customer->email }}</h4>    
              <h4>Customer Address: {{ $customer->address }}</h4> 
              <h4>Customer Registered at: {{ $customer->created_at }}</h4>              
        </div>
        <div class="card-footer">
                <a href="/customer/{{ $customer->id }}/edit" class="btn btn-primary float-left">Edit</a>
                <form action="/customer/{{ $customer->id }}" method="post">
                    @method('DELETE')
                    @csrf
                    <input type="submit" class="btn btn-danger float-right" value="Delete">
                </form>
        </div>
    </div>

@endsection