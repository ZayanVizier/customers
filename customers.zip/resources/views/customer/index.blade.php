@extends('layout')

@section('content')

    <div class="card">
        <div class="card-body">
            <h1 class="float-left">List Customers</h1> 
            <a href="/customer/create" class="btn btn-primary float-right">Create New Customer</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <ul>
                @foreach ($customers as $customer)
                    <li> <a href="/customer/{{ $customer->id }}">{{ $customer->name }}</a></li> 
                @endforeach                   
            </ul> 
        </div>
    </div>

@endsection