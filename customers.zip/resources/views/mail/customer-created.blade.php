@component('mail::message')
# Introduction Customer {{ $customer->name }}

The body of your message.

{{ $customer->address }}

@component('mail::button', ['url' => ''])
Button Text
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
