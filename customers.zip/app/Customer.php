<?php

namespace App;

use App\Events\CustomerCreated;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $guarded = [];

    protected $dispatchesEvents = [
        'created' => CustomerCreated::class
    ];
    
    public function owner()
    {
        return $this->belongsTo(User::class);  
    }

}
