<?php /* C:\xampp\htdocs\customers\resources\views/customer/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h2 class="float-left">Customer # <?php echo e($customer->id); ?></h2> 
            <a href="/customer" class="btn btn-secondary float-right">Back</a>
        </div>
        <div class="card-body">
              <h4>Customer Name: <?php echo e($customer->name); ?></h4>    
              <h4>Customer Email: <?php echo e($customer->email); ?></h4>    
              <h4>Customer Address: <?php echo e($customer->address); ?></h4> 
              <h4>Customer Registered at: <?php echo e($customer->created_at); ?></h4>              
        </div>
        <div class="card-footer">
                <a href="/customer/<?php echo e($customer->id); ?>/edit" class="btn btn-primary float-left">Edit</a>
                <form action="/customer/<?php echo e($customer->id); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="submit" class="btn btn-danger float-right" value="Delete">
                </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>