<?php /* C:\xampp\htdocs\customers\resources\views/customer/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header">
            <h1 class="float-left">Create Customer</h1> 
            <a href="/customer" class="btn btn-secondary float-right mt-2">Back</a>
        </div>
        <div class="card-body">
                <form action="/customer" method="POST" name="request">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="InputName">Name</label>
                        <input type="text" class="form-control" id="InputName" name="name" value="<?php echo e(old('name')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="InputEmail">Email</label>
                        <input type="email" class="form-control" id="InputEmail" name="email" <?php echo e(old('email')); ?> required>
                    </div>
                    <div class="form-group">
                        <label for="InputAddress">Address</label>
                        <input type="text" class="form-control" id="InputAddress" name="address" <?php echo e(old('address')); ?> required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
        </div>
        
            <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>