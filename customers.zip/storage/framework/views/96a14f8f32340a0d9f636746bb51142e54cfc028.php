<?php /* C:\xampp\htdocs\customers\resources\views/customer/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <h1 class="float-left">List Customers</h1> 
            <a href="/customer/create" class="btn btn-primary float-right">Create New Customer</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <ul>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <a href="/customer/<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></a></li> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
            </ul> 
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>