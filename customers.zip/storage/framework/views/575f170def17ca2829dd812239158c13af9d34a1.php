<?php /* C:\xampp\htdocs\customers\resources\views/mail/customer-created.blade.php */ ?>
<?php $__env->startComponent('mail::message'); ?>
# Introduction Customer <?php echo e($customer->name); ?>


The body of your message.

<?php echo e($customer->address); ?>


<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
